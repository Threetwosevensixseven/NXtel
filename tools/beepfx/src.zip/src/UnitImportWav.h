//---------------------------------------------------------------------------

#ifndef UnitImportWavH
#define UnitImportWavH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TFormImportWAV : public TForm
{
__published:	// IDE-managed Components
	TOpenDialog *OpenDialogWAV;
	TSpeedButton *SpeedButtonLoadWAV;
	TEdit *EditSampleFile;
	TPaintBox *PaintBoxSample;
	TSpeedButton *SpeedButtonSelectAll;
	TLabel *LabelSampleSize;
	TTrackBar *TrackBarVolume;
	TTrackBar *TrackBarQuality;
	TLabel *Label1;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall SpeedButtonLoadWAVClick(TObject *Sender);
	void __fastcall PaintBoxSamplePaint(TObject *Sender);
	void __fastcall PaintBoxSampleMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
	void __fastcall PaintBoxSampleMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
	void __fastcall SpeedButtonSelectAllClick(TObject *Sender);
	void __fastcall TrackBarVolumeChange(TObject *Sender);
	void __fastcall TrackBarQualityChange(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
public:		// User declarations
	__fastcall TFormImportWAV(TComponent* Owner);

	unsigned short __fastcall RdWordLH(unsigned char*);
	unsigned int __fastcall RdDWordLH(unsigned char*);
	void __fastcall Error(AnsiString);
	bool __fastcall LoadWAV(AnsiString);
	int __fastcall CalcSampleSize(void);
	void __fastcall DrawSample(void);
	void __fastcall ConvertSample(void);
	void __fastcall NewSample(void);

	short int *SampleData;
	int SampleSize;
	int SampleRate;
	float SampleStart;
	float SampleEnd;
	float SampleVolume;
};
//---------------------------------------------------------------------------
extern PACKAGE TFormImportWAV *FormImportWAV;
//---------------------------------------------------------------------------
#endif
