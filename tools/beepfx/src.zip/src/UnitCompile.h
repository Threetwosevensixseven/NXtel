//---------------------------------------------------------------------------

#ifndef UnitCompileH
#define UnitCompileH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TFormCompile : public TForm
{
__published:	// IDE-managed Components
	TGroupBox *GroupBox1;
	TLabel *LabelAddress;
	TLabel *LabelSize;
	TButton *ButtonCompile;
	TButton *ButtonCancel;
	TEdit *EditAddress;
	TEdit *EditSize;
	TRadioButton *RadioButtonBinary;
	TRadioButton *RadioButtonAssembly;
	TRadioButton *RadioButtonTape;
	TCheckBox *CheckBoxPlayer;
	TCheckBox *CheckBoxTest;
	TSaveDialog *SaveDialogData;
	void __fastcall ButtonCancelClick(TObject *Sender);
	void __fastcall ButtonCompileClick(TObject *Sender);
	void __fastcall RadioButtonBinaryClick(TObject *Sender);
	void __fastcall EditAddressExit(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall EditAddressKeyPress(TObject *Sender, char &Key);
	void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TFormCompile(TComponent* Owner);
	AnsiString __fastcall ExtractName(AnsiString);
	void __fastcall UpdateAll(void);
	void __fastcall CalcSize(void);
	int Address;
	int Size;
	int PlayerSize;
};
//---------------------------------------------------------------------------
extern PACKAGE TFormCompile *FormCompile;
//---------------------------------------------------------------------------
#endif
